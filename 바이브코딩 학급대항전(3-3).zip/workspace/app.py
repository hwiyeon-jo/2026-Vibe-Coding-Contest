from flask import Flask, render_template, request, jsonify, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "student_tracker_secret_key"  # 로그인을 위한 세션 암호화 키

# 임시 데이터 저장소 (서버 메모리 기반)
users_db = {
    "admin": "1234"  # 기본 테스트용 계정 (아이디: admin, 비밀번호: 1234)
}

data_store = {
    "timetable": [
        {"id": 1, "subject": "국어", "time": "09:00 - 10:00"},
        {"id": 2, "subject": "수학", "time": "10:30 - 12:00"}
    ],
    "target_hours": 4,
    "test_scores": [60, 72, 85]
}

# --- [페이지 라우팅] ---
@app.route('/')
def index():
    if "user_id" not in session:
        return redirect(url_for('login'))
    return render_template('index.html', user_id=session["user_id"])

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        user_pw = request.form.get('user_pw')
        
        if user_id in users_db and users_db[user_id] == user_pw:
            session["user_id"] = user_id
            return redirect(url_for('index'))
        else:
            return "<script>alert('아이디 또는 비밀번호가 틀렸습니다.'); history.back();</script>"
            
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        user_pw = request.form.get('user_pw')
        
        if not user_id or not user_pw:
            return "<script>alert('모든 필드를 입력해주세요.'); history.back();</script>"
        if user_id in users_db:
            return "<script>alert('이미 존재하는 아이디입니다.'); history.back();</script>"
            
        users_db[user_id] = user_pw
        return "<script>alert('회원가입이 완료되었습니다! 로그인해주세요.'); location.href='/login';</script>"
        
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))


# --- [루틴 트래커 데이터 API] ---
@app.route('/api/timetable', methods=['GET', 'POST', 'DELETE'])
def handle_timetable():
    if request.method == 'GET':
        return jsonify(data_store["timetable"])
    elif request.method == 'POST':
        req_data = request.json
        new_item = {"id": req_data.get("id"), "subject": req_data.get("subject"), "time": req_data.get("time")}
        data_store["timetable"].append(new_item)
        return jsonify({"status": "success", "data": data_store["timetable"]})
    elif request.method == 'DELETE':
        item_id = int(request.args.get('id'))
        data_store["timetable"] = [item for item in data_store["timetable"] if item["id"] != item_id]
        return jsonify({"status": "success", "data": data_store["timetable"]})

@app.route('/api/target', methods=['GET', 'POST'])
def handle_target():
    if request.method == 'GET':
        return jsonify({"target_hours": data_store["target_hours"]})
    elif request.method == 'POST':
        data_store["target_hours"] = int(request.json.get("target_hours", 4))
        return jsonify({"status": "success", "target_hours": data_store["target_hours"]})

@app.route('/api/scores', methods=['GET', 'POST'])
def handle_scores():
    if request.method == 'GET':
        return jsonify(data_store["test_scores"])
    elif request.method == 'POST':
        score = int(request.json.get("score"))
        data_store["test_scores"].append(score)
        return jsonify({"status": "success", "scores": data_store["test_scores"]})

if __name__ == '__main__':
    app.run(debug=True, port=5000)